export default function Timer(props){
    return(
        <>
            <div className="timer">
                <div className="timer">
                    <h1>TIMER: {props.name}</h1>
                    <h3>{props.value}</h3>
                </div>
            </div>
        </>
    );
}