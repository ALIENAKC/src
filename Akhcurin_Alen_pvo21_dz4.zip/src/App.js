import logo from './logo.svg';
import my_logo from './my_logo.svg';
import './App.css';
import React from 'react';
import Timer from './Timer';

export default class App extends React.Component {
  constructor(p)
  {
    super(p);
    this.color = p.color ? p.color : "blue";
    this.initialTime1 = new Date(0,0,0,0,0,10);
    this.initialTime2 = new Date(0,0,0,0,0,25);

    this.state = {
      dt1: this.initialTime1,
      dt2: this.initialTime2
    };
    this.turn = new Boolean(true);
  }
  componentDidMount()
  {
    setInterval(this.updateTime, 1000);
  }
  subOneSecond (time) 
  {
    // console.log(time.toLocaleTimeString());
    if(time.getMinutes() == 0 && time.getSeconds() == 0)
    {
      console.log("stop");
      window.location.reload();
      return new Date(0,0,0,0,0,0);
    }
    if(time === this.initialTime1)
    {
      this.initialTime1 = new Date(this.initialTime1.getTime() - 500);
      return this.initialTime1;
    }
    else
    {
      this.initialTime2 = new Date(this.initialTime2.getTime() - 500);
      return this.initialTime2;
    }
  }
  clickTimer = ()=>
  {
    this.turn = !this.turn;
    console.log(this.turn);
  }
  updateTime = () =>
  {
    if(this.turn)
    {
      this.setState({
        dt1: this.subOneSecond(this.initialTime1),
      });
    }
    else
    {
      this.setState({
        dt2: this.subOneSecond(this.initialTime2)
      });
    }
  }

  render(){
  let date = new Date().toLocaleDateString();
  
  return (
    <div className="App">
      <header className="App-header">
        {/* <img src={logo} className="App-logo" alt="logo" /> */}
        <img src={my_logo} className="App-logo" alt="logo" />
        <p style={{fontFamily: "Arial"}}>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <p>
          {date}
        </p>
        <button onClick={this.clickTimer}>Click</button>
        <div className="timerCont">
            <Timer name="Timer 1" value={this.state.dt1.toLocaleTimeString()} />
            <Timer name="Timer 2" value={this.state.dt2.toLocaleTimeString()} />
        </div>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
  }
}
